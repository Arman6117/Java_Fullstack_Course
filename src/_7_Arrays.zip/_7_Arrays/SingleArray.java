package _7_Arrays;

public class SingleArray {
    public static void main(String[] args) {
        /*
        int arr[];  => Declaring array
        arr = new int[5];  => Initialization
        System.out.println(arr[0]);
        System.out.println(arr[1]);
        System.out.println(arr[2]);
        System.out.println(arr[3]);
        System.out.println(arr[4]);

         */

//        int a[] = new int[]   => Invalid
//         int a[] = new int[] {10,20,30,40,50};  => Valid

//        Integer arr[] = new Integer[5]{10,20,30,40}; => Invalid
        Integer arr[] = new Integer[]{10,20,30,40}; // Valid
        System.out.println(arr[0]);

    }
}
