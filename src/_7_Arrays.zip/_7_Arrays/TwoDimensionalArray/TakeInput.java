package _7_Arrays.TwoDimensionalArray;

public class TakeInput {
    public static void main(String[] args) {
        int[][] arr = new int[3][3];
        System.out.println("Row length: " + arr.length);
    }
}
