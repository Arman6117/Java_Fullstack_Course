package _3_Operators;

public class Relational {
    public static void main(String[] args) {
        int a = 5;
        int b = 6;
        boolean r = a <= b;
        System.out.println(r);
        System.out.println(a > b);

        if (a !=b && a <= b && b ==6) {
            System.out.println("Condition valid");
        } else  {
            System.out.println("Condition in valid");
        }
    }
}
