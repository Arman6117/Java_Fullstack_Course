package Practice;

public class EvenOdd {
    public static void main(String[] args) {
        System.out.println("Even number: ");
        for (int i = 1; i <=50 ; i++) {
            if (i % 2 ==0) {
                System.out.println(i);
            }
        }
        System.out.println();
        System.out.println("Odd number: ");
        for (int i =  1; i <=50 ; i++) {
            if (i % 2 !=0) {
                System.out.println( i);
            }
        }
    }
}
