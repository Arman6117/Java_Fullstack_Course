package _1_Basics;

public class ThirdProgram {
    public static void main(int[] b ){
        System.out.println("Main method b");
        int a = 5;
        int r =a+ a;
        System.out.println("r" + a);
        System.out.println("Hello \n Welcome to JSE");
    }

    public static void main(String[] args) {
        System.out.println("Main method");
        int[] b = {10,20,30};
        main(b);
    }
}
