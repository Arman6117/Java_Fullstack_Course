package _1_Basics;

public class ForthProgram {
    public static void main(String[] args) {
        System.out.println(args[2]);
    }
}
