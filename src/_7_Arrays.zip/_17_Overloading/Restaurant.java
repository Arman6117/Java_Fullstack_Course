package _17_Overloading;
      interface  Rest {
          void menu();
          void bill();
      }

public class Restaurant {
}
