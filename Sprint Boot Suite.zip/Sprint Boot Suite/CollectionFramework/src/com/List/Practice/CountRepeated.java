package com.List.Practice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class CountRepeated {
  public static void main(String[]args) {
	  ArrayList<String> li = new ArrayList<>();
	  li.add("Baby");
	  li.add("Soap");
	  li.add("Ball");
	  li.add("Baby");
	  li.add("Baby");
	  li.add("Shampoo");
	  li.add("Ball");
	  li.add("Chalk");
	  li.add("Makeup");
	  
	  System.out.println("Normal list: ");
	  System.out.println(li);t
	   
	  Map<String, Integer> freq = new HashMap<>();
	  
	  for(String ele:li) {
		  freq.put(ele, freq.getOrDefault(ele, 0)+1);
	  }
	  
	  Set<Entry<String, Integer>> entry = freq.entrySet();
	  System.out.println(entry);
	  for(Entry<String, Integer> en:entry) {
		  if(en.getValue() > 1) {
			  System.out.print(en.getKey() + " = " + en.getValue() + " ");
		  }
	  }
	  System.out.println();
//	  System.out.println(freq);
	  
	
}
}
