package com.List.Practice;

import java.util.ArrayList;

public class ListPrimeNumbers {

	public static void main(String[] args) {
		
		ArrayList<Integer> prime=  new ArrayList<>();
		System.out.println("Hello");
		for(int i = 2; i <= 50; i++) {
			int factCnt =0;
			for(int j = 2; j<= i; i++) {
				if(i % j == 0) {
					factCnt++;
				}
			}
			if(factCnt == 1) {
				prime.add(i);
			}
		}
		System.out.println(prime);
 
	}

}
