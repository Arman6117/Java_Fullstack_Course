package com.customException;

public class NoDiscountException extends Exception {
   public NoDiscountException(String msg) {
	   super(msg);
   }
}
