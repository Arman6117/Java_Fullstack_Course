package com.customException;

public class LoginException extends Exception {
	
	public LoginException(String msg) {
		super(msg);
	}

}
