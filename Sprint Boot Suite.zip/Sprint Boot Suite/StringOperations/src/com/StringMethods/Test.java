package com.StringMethods;

public class Test {
  public static void main(String[] args) {
	  String str1 = "Hello";
	  String str2 = "Hii";
	  String str3 = "Hello";
	  System.out.println(str1);
  }
}
