package com.StringMethods.Assignments;

public class _05_RemoveWhiteSpace {
   public static void main(String[] args) {
	   String  str  = "   Hello  ";
	   System.out.println(str.trim());
   }
}
