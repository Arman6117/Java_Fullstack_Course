package com.StringMethods.Assignments;

public class _01_NumberOfCharacters {

	public static void main(String[] args) {
	  String str = "Java is super";
	  System.out.println(str.length());

	}

}
