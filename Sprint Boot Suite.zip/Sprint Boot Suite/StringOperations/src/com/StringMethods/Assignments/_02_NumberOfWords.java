package com.StringMethods.Assignments;

public class _02_NumberOfWords {

	public static void main(String[] args) {
		String str  = "Java is super";
		System.out.println("Number of words in string: " +str.split(" ").length);

	}

}
