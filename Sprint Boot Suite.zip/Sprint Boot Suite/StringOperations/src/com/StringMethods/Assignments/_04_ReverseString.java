package com.StringMethods.Assignments;

public class _04_ReverseString {

	public static void main(String[] args) {
	   String str = new StringBuilder("Hello").reverse().toString();
	   System.out.println(str);
	}

}
