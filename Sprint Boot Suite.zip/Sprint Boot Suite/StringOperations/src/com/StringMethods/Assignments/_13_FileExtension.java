package com.StringMethods.Assignments;

import java.util.Arrays;

public class _13_FileExtension {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "index.html";
		String word[]=str.split("\\.");
		System.out.println((word[1]));
		
	}

}